require('../index')

const Discord = require('discord.js');
const client = require('../index');
var colors = require('colors');

client.on("ready", () => {
    console.log(`Servidor onde estou:\n`.cyan,client.guilds.cache.map((guild) => guild.name).join('\n').brightCyan)
    
})